# 🚀 字段拓展快速参考指南

## 📝 添加新字段的5步流程

### 1️⃣ 确定字段类型
```
auto_generate    → 需要从产品数据生成
walmart_field    → 使用Walmart预定义枚举值  
default_value    → 使用固定默认值
wc_attribute     → 从WooCommerce属性获取
```

### 2️⃣ 前端配置 (woo-walmart-sync.php)
```javascript
// 添加到对应数组
var autoGenerateFields = [..., 'newField'];
var walmartFields = {..., 'newField': 'defaultValue'};
var defaultValueFields = {..., 'newField': 'fixedValue'};

// 添加说明
function getAutoGenerationRule(attributeName) {
    var rules = {
        'newField': '字段生成规则说明'
    };
    return rules[attributeName] || '自动生成';
}
```

### 3️⃣ 后端实现 (includes/class-product-mapper.php)
```php
// 在generate_special_attribute_value方法中添加
case 'newfield':
    return $this->generate_new_field($product);

// 实现生成方法
private function generate_new_field($product) {
    // 生成逻辑
    return 'generated_value';
}
```

### 4️⃣ 数据类型转换（如需要）
```php
// 在convert_field_data_type方法中添加
case 'newfield':
    return $this->convert_new_field_type($value);
```

### 5️⃣ 测试验证
```php
// 创建测试脚本验证字段生成
$value = $mapper->generate_special_attribute_value('newField', $product, 1);
echo "生成值: {$value}";
```

## 🔧 常用代码模板

### 自动生成字段模板
```php
case 'newfieldname':
    // 1. 尝试从产品属性获取
    $attr_value = $product->get_attribute('Attribute Name');
    if (!empty($attr_value)) {
        return $attr_value;
    }
    
    // 2. 从产品基本信息生成
    $product_data = $product->get_name() . ' ' . $product->get_description();
    
    // 3. 根据分类判断
    $categories = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']);
    
    // 4. 返回默认值
    return 'default_value';
```

### 枚举字段模板
```javascript
// 前端枚举选项
var walmartFieldOptions = {
    'newEnumField': ['Option1', 'Option2', 'Option3']
};

// 后端验证
private function validate_enum_field($value, $field_name) {
    $valid_options = [
        'newEnumField' => ['Option1', 'Option2', 'Option3']
    ];
    
    return isset($valid_options[$field_name]) && 
           in_array($value, $valid_options[$field_name]);
}
```

### 条件生成模板
```php
private function generate_conditional_field($product, $field_name) {
    $categories = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']);
    $category_names = strtolower(implode(' ', $categories));
    
    if (strpos($category_names, 'furniture') !== false) {
        return 'furniture_specific_value';
    } elseif (strpos($category_names, 'electronic') !== false) {
        return 'electronic_specific_value';
    }
    
    return 'general_value';
}
```

## 📊 字段分组规则

### Orderable字段（影响订购）
```php
$orderable_fields = [
    'price',                    // 价格
    'productIdentifiers',       // 产品标识符
    'fulfillmentLagTime',      // 履行时间
    'shippingWeight',          // 运输重量
    'stateRestrictions'        // 州限制
];
```

### Visible字段（产品展示）
```php
// 其他所有字段默认为Visible，包括：
// productName, brand, shortDescription, keyFeatures,
// mainImageUrl, material, color, dimensions 等
```

## ⚡ 性能优化技巧

### 缓存字段值
```php
private function get_cached_value($product_id, $field_name) {
    $cache_key = "walmart_{$field_name}_{$product_id}";
    $value = wp_cache_get($cache_key);
    
    if ($value === false) {
        $value = $this->generate_field_value($product_id, $field_name);
        wp_cache_set($cache_key, $value, '', 3600); // 缓存1小时
    }
    
    return $value;
}
```

### 批量预加载
```php
// 批量获取产品属性，避免重复查询
$all_attributes = [];
foreach ($product_ids as $id) {
    $all_attributes[$id] = get_post_meta($id);
}
```

## 🐛 常见问题快速修复

### 问题1: 字段值为空
```php
// 检查点：
// 1. 产品是否有对应属性
// 2. 生成逻辑是否正确
// 3. 是否有默认值

// 调试代码：
$debug = $this->debug_field_generation($product_id, $field_name);
var_dump($debug);
```

### 问题2: 数据类型错误
```php
// 确保类型转换正确
case 'numericfield':
    return is_numeric($value) ? (float)$value : 0.0;

case 'stringfield':
    return is_string($value) ? $value : '';

case 'arrayfield':
    return is_array($value) ? $value : [$value];
```

### 问题3: 枚举值无效
```php
// 添加枚举值验证和映射
private function map_enum_value($field_name, $value) {
    $mappings = [
        'condition' => [
            '新的' => 'New',
            '二手' => 'Used',
            '翻新' => 'Refurbished'
        ]
    ];
    
    if (isset($mappings[$field_name][$value])) {
        return $mappings[$field_name][$value];
    }
    
    return $value;
}
```

## 🧪 测试模板

### 完整测试脚本模板
```php
<?php
// 启用错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 输出管理
$output_file = 'test-results.txt';
$output = '';

function log_output($message) {
    global $output;
    $output .= $message . "\n";
    echo $message . "\n";
}

log_output("=== 字段测试开始 ===");

// WordPress加载（使用绝对路径）
$wp_path = 'D:\\phpstudy_pro\\WWW\\test.localhost';
require_once $wp_path . '\\wp-config.php';
require_once $wp_path . '\\wp-load.php';

// 插件加载
$plugin_path = 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-content\\plugins\\woo-walmart-sync';
define('WOO_WALMART_SYNC_PATH', $plugin_path . '\\');
require_once $plugin_path . '\\includes\\class-product-mapper.php';

$mapper = new Woo_Walmart_Product_Mapper();
$reflection = new ReflectionClass($mapper);
$method = $reflection->getMethod('convert_field_data_type');
$method->setAccessible(true);

// 测试数据转换
$field_name = 'your_field_name';
$test_values = [
    'normal_value',
    '',
    null,
    ['array', 'value']
];

foreach ($test_values as $i => $test_value) {
    log_output("\n测试 " . ($i + 1) . ":");
    log_output("输入: " . (is_null($test_value) ? 'null' :
              (is_array($test_value) ? json_encode($test_value) : "'{$test_value}'")));

    try {
        $result = $method->invoke($mapper, $field_name, $test_value);
        log_output("输出: " . json_encode($result, JSON_UNESCAPED_UNICODE));
        log_output("类型: " . gettype($result));
        log_output("✅ 成功");
    } catch (Exception $e) {
        log_output("❌ 失败: " . $e->getMessage());
    }
}

// 保存结果
file_put_contents($output_file, $output);
log_output("\n结果已保存到: {$output_file}");
?>
```

### 快速单字段测试
```php
<?php
// 快速测试单个字段
require_once 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-config.php';
require_once 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-load.php';

define('WOO_WALMART_SYNC_PATH', 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-content\\plugins\\woo-walmart-sync\\');
require_once WOO_WALMART_SYNC_PATH . 'includes/class-product-mapper.php';

$mapper = new Woo_Walmart_Product_Mapper();
$reflection = new ReflectionClass($mapper);
$method = $reflection->getMethod('convert_field_data_type');
$method->setAccessible(true);

$field_name = 'occasion'; // 替换为要测试的字段
$test_value = 'Christmas;New Year;Black Friday'; // 替换为测试值

try {
    $result = $method->invoke($mapper, $field_name, $test_value);
    echo "字段: {$field_name}\n";
    echo "输入: {$test_value}\n";
    echo "输出: " . json_encode($result, JSON_UNESCAPED_UNICODE) . "\n";
    echo "类型: " . gettype($result) . "\n";
    echo "✅ 测试成功\n";
} catch (Exception $e) {
    echo "❌ 测试失败: " . $e->getMessage() . "\n";
}
?>
```

### 测试注意事项
1. **路径配置**：使用绝对路径，Windows下用双反斜杠
2. **输出处理**：同时输出到控制台和文件
3. **错误报告**：启用完整错误报告便于调试
4. **边界测试**：测试空值、null、数组等不同类型

## 📋 完整检查清单

### 开发检查
- [ ] 前端配置已更新
- [ ] 后端逻辑已实现
- [ ] 字段说明已添加
- [ ] 数据类型转换已配置
- [ ] 字段分组已设置

### 测试检查
- [ ] 创建了测试脚本
- [ ] 测试了数据类型转换
- [ ] 测试了边界值情况
- [ ] 验证了API数据格式
- [ ] 测试了完整映射流程
- [ ] 检查了字段在API中的位置

### 部署检查
- [ ] 测试已通过
- [ ] 缓存已清理
- [ ] 文档已更新
- [ ] 配置已备份
- [ ] 回滚方案已准备

## 🔗 相关文件位置

```
woo-walmart-sync.php           → 前端JavaScript配置
includes/class-product-mapper.php → 后端生成逻辑
字段拓展开发文档.md              → 详细开发文档
```

## 💡 最佳实践

1. **命名规范**: 使用驼峰命名法，与Walmart API保持一致
2. **错误处理**: 每个生成函数都要有默认值和异常处理
3. **性能考虑**: 避免在生成函数中进行复杂查询
4. **数据验证**: 确保生成的值符合Walmart规范
5. **测试覆盖**: 为每个新字段创建测试用例

## 🎯 实际案例：occasion字段测试

### 测试脚本
```php
<?php
// occasion字段测试示例
require_once 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-config.php';
require_once 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-load.php';

define('WOO_WALMART_SYNC_PATH', 'D:\\phpstudy_pro\\WWW\\test.localhost\\wp-content\\plugins\\woo-walmart-sync\\');
require_once WOO_WALMART_SYNC_PATH . 'includes/class-product-mapper.php';

$mapper = new Woo_Walmart_Product_Mapper();
$reflection = new ReflectionClass($mapper);
$method = $reflection->getMethod('convert_field_data_type');
$method->setAccessible(true);

// 测试完整节日列表
$test_value = 'Labor Day;Memorial Day;Independence Day;Black Friday;Cyber Monday;Christmas;New Year;Presidents\' Day;Thanksgiving';

$result = $method->invoke($mapper, 'occasion', $test_value);

echo "输入: {$test_value}\n";
echo "输出: " . json_encode($result, JSON_UNESCAPED_UNICODE) . "\n";
echo "数量: " . count($result) . "\n";
echo "类型: " . gettype($result) . "\n";

// 验证结果
if (is_array($result) && count($result) === 9) {
    echo "✅ 测试通过：成功转换为9个节日的数组\n";
} else {
    echo "❌ 测试失败：结果不符合预期\n";
}
?>
```

### 预期输出
```
输入: Labor Day;Memorial Day;Independence Day;Black Friday;Cyber Monday;Christmas;New Year;Presidents' Day;Thanksgiving
输出: ["Labor Day","Memorial Day","Independence Day","Black Friday","Cyber Monday","Christmas","New Year","Presidents' Day","Thanksgiving"]
数量: 9
类型: array
✅ 测试通过：成功转换为9个节日的数组
```

### 测试要点
- ✅ 分号分隔字符串正确转换为数组
- ✅ 包含所有9个预设节日
- ✅ 数组格式符合API要求
- ✅ 字符串正确trim处理

---

💡 **提示**: 保存此文档到书签，方便快速查阅！每次添加新字段都可以参考这个流程和测试模板。
